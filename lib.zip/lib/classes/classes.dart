class Photos {
  Photos({required this.name});
  String name;
}

class Swipper {
  String image;
  Swipper({required this.image});
}
