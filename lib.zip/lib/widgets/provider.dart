class AppProvider{
  void addtofavourites(){}
}
