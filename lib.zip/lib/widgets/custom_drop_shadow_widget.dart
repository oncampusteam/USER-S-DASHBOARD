// import 'package:flutter/material.dart';

// class CustomDropShadowWidget extends StatefulWidget {
//   final Widget widget;
//   final double shadowTopPosition;
//   final double shadowBottomPosition;
//   final double shadowLeftPositon;
//   final double shadowRightPosition;
//   const CustomDropShadowWidget({
//     super.key,
//     required this.widget,
//     required this.shadowTopPosition,
//     required this.shadowBottomPosition,
//     required this.shadowLeftPositon,
//     required this.shadowRightPosition
//     });

//   @override
//   State<CustomDropShadowWidget> createState() => _CustomDropShadowWidgetState();
// }

// class _CustomDropShadowWidgetState extends State<CustomDropShadowWidget> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(child: Stack(children: [
//       Positioned(
//         top: widget.shadowTopPosition,
//         left: widget.shadowLeftPositon,
//         right: widget.shadowRightPosition,
//         bottom: widget.shadowBottomPosition,
//         child: )
//     ],),);
//   }
// }
