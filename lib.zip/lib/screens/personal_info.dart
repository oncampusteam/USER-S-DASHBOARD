import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:on_campus/screens/customStepper.dart';
import 'package:on_campus/screens/university_info.dart';

class PersonalInfo extends StatefulWidget {
  final String username;
  const PersonalInfo({super.key, required this.username});

  @override
  State<PersonalInfo> createState() => _PersonalInfoState();
}

class _PersonalInfoState extends State<PersonalInfo> {
  TextEditingController firstName = TextEditingController();
  TextEditingController surName = TextEditingController();
  TextEditingController age = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController mobileNumber = TextEditingController();
  TextEditingController gender = TextEditingController();
  TextEditingController region = TextEditingController();
  TextEditingController city = TextEditingController();
  TextEditingController houseAddress = TextEditingController();
  int currentStep = 0;
  final List<String> steps = [
    'Personal Info',
    'University Info',
    'Guardian Details',
    'Confirm'
  ];

  Widget PersonalInfoForm() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 17),
            Row(
              children: [
                Text(
                  "First Name",
                  style: TextStyle(
                    height: 2,
                    fontWeight: FontWeight.w600,
                    fontSize: 11.5,
                  ),
                ),
                Text(
                  "*",
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ],
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: firstName, hint: "Enter your first name"),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  "Surname",
                  style: TextStyle(
                    height: 2,
                    fontWeight: FontWeight.w600,
                    fontSize: 11.5,
                  ),
                ),
                Text(
                  "*",
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ],
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: surName, hint: "Enter your Surname"),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  "Email address",
                  style: TextStyle(
                    height: 2,
                    fontWeight: FontWeight.w600,
                    fontSize: 11.5,
                  ),
                ),
                Text(
                  "*",
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ],
            ),
            Container(
              height: 40,
              child:
                  customTextField(controller: email, hint: "Enter your email"),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  "Phone number",
                  style: TextStyle(
                    height: 2,
                    fontWeight: FontWeight.w600,
                    fontSize: 11.5,
                  ),
                ),
                Text(
                  "*",
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ],
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: mobileNumber, hint: "Enter your phone number"),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  "Gender",
                  style: TextStyle(
                    height: 2,
                    fontWeight: FontWeight.w600,
                    fontSize: 11.5,
                  ),
                ),
                Text(
                  "*",
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
              ],
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: gender, hint: "Choose your gender"),
            ),
          ],
        ),
      ),
    );
  }

  Widget UniversityInfoForm() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        // height: 700,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 17),
            Text(
              "Program of study",
              style: TextStyle(height: 2),
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: firstName, hint: "Enter your Program of study"),
            ),
            SizedBox(height: 20),
            Text(
              "Year",
              style: TextStyle(height: 2),
            ),
            Container(
              height: 40,
              child:
                  customTextField(controller: surName, hint: "Eg. level 100"),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget GuardianDetailsForm() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 17),
            Text(
              "Guardian name",
              style: TextStyle(height: 2),
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: firstName, hint: "Enter your guardian's name"),
            ),
            SizedBox(height: 20),
            Text(
              "Emergency contact (1)",
              style: TextStyle(height: 2),
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: surName, hint: "Enter emergency contact"),
            ),
            SizedBox(height: 20),
            Text(
              "Emergency contact (2)",
              style: TextStyle(height: 2),
            ),
            Container(
              height: 40,
              child: customTextField(
                  controller: surName, hint: "Enter emergency contact"),
            ),
          ],
        ),
      ),
    );
  }

  Widget ConfirmationPage() {
    return Container(
      child: Text("four"),
    );
  }

  Widget customTextField(
      {required TextEditingController controller, String? hint}) {
    return TextField(
        //   onChanged: (){},
        //   focusNode:,
        controller: controller,
        obscureText: false,
        enableSuggestions: true,
        autocorrect: false,
        cursorColor: Colors.white,
        style: const TextStyle(color: Colors.grey),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(
            color: Colors.grey,
            fontSize: 12.5,
          ),
          filled: true,
          fillColor: Colors.grey.withOpacity(0.3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(width: 0, style: BorderStyle.none),
          ),
        ),
        keyboardType: TextInputType.visiblePassword);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          child: Container(
            height: MediaQuery.of(context).size.height,
            color: Colors.white,
            width: double.infinity,
            padding: EdgeInsets.only(
              left: 20.h,
              right: 20.h,
              top: 30.h,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 30.h,
                  width: 30.w,
                  foregroundDecoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.03),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(Icons.chevron_left,
                        color: Colors.black, size: 24.w),
                  ),
                ),
                Transform.translate(
                  offset: Offset(0, -65),
                  child: Column(
                    children: [
                      Align(
                        child: Image.asset("assets/personal_info/user logo.png",
                            height: 110.h, width: 100.w),
                      ),
                      Align(
                        child: Text(
                          widget.username,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: "Poppins-Bold",
                            fontSize: 22.sp,
                            letterSpacing: 0.15.w,
                            color: const Color(0xFF323232),
                          ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Align(
                        alignment: Alignment.center,
                        child: Text(
                          "Personal Information",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20,
                          ),
                        ),
                      ),
                      SizedBox(height: 6),
                      Container(
                        height: MediaQuery.of(context).size.height,
                        padding: EdgeInsets.symmetric(vertical: 20),
                        child: Column(
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomStepper(
                              currentStep: currentStep,
                              stepTitles: steps,
                              onStepTapped: (index) {
                                setState(() => currentStep = index);
                              },
                            ),
                            // Your step content here based on currentStep
                            Container(
                              child: IntrinsicHeight(
                                child: IndexedStack(
                                  index: currentStep,
                                  children: [
                                    PersonalInfoForm(),
                                    UniversityInfoForm(),
                                    GuardianDetailsForm(),
                                    ConfirmationPage(),
                                  ],
                                ),
                              ),
                            ),
                            // Navigation buttons
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                if (currentStep > 0)
                                  TextButton(
                                    onPressed: () =>
                                        setState(() => currentStep--),
                                    child: Text('Back',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                        )),
                                  ),
                                if (currentStep < steps.length - 1)
                                  Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                      height: 50,
                                      width: MediaQuery.of(context).size.width *
                                          0.5,
                                      child: ElevatedButton(
                                          onPressed: () =>
                                              setState(() => currentStep++),
                                          child: Text('Next',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                              )),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor: Color(0xFF00EFD1),
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(15),
                                              ),
                                            ),
                                          )),
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
