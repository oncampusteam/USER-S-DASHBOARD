import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import 'package:on_campus/screens/personal_info.dart';

class Profile extends StatefulWidget {
  final String username;
  const Profile({super.key, required this.username});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  int selectedIndex = 3;
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: SafeArea(
        child: Scaffold(
          body: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 15.h),
              color: Colors.white,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back_ios_rounded, size: 15),
                        onPressed: () {},
                      ),
                      Text(
                        "Profile",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      IconButton(
                          icon: IconButton(
                            icon: Image.asset(
                                "assets/user_interface_icons/profile_screen/editprofile.png"),
                            onPressed: () {},
                          ),
                          onPressed: () {}),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        height: 55,
                        width: 55,
                        child: CircleAvatar(
                          backgroundImage: AssetImage(
                            "assets/welcome_screen_4/welcomeImage4.jpg",
                          ),
                        ),
                      ),
                      SizedBox(width: 20),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Kwame Obeng",
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                          Text(
                            "oncampus@gmail.com",
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                  SizedBox(height: 10.h),
                  ListTile(
                    onTap: () {
                      Get.to(
                        () => PersonalInfo(username: widget.username),
                        transition: Transition.fadeIn,
                        duration: const Duration(milliseconds: 600),
                        curve: Curves.easeIn,
                      );
                    },
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/User,Profile.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Personal Information"),
                    trailing: IconButton(
                      icon: Icon(Icons.arrow_forward_ios_outlined, size: 10),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/credit-cards.svg"),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                    title: Text("Payment History"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/save-2.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Bookings"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/heart.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Wishlist"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/Chat, Messages.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Message"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/share.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Share the app"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/shop-add.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Host Business or Service"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/refer.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Refer & Earn"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/help.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Help"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                  ListTile(
                    leading: IconButton(
                      icon: SvgPicture.asset(
                          "assets/user_interface_icons/profile_screen/logout.svg"),
                      onPressed: () {},
                    ),
                    title: Text("Log out"),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios_outlined,
                        size: 15,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      onPressed: () {},
                    ),
                    style: ListTileStyle.drawer,
                    contentPadding: EdgeInsets.all(0),
                    dense: true,
                    visualDensity: VisualDensity.compact,
                  ),
                  Divider(
                    color: Colors.grey.withOpacity(0.1),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
