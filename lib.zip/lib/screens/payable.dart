import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get_core/src/get_main.dart';

class Payable extends StatelessWidget {
  const Payable({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: Icon(Icons.close),
                ),
              ),
            ),
            SizedBox(height: 20),
            Text("Payable Amount"),
            SizedBox(height: 10),
            Text(
              "GHS 4,040.00",
              style: TextStyle(
                fontSize: 32.sp.clamp(0, 32),
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 40),
            Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 12,
                  horizontal: 25,
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            SvgPicture.asset(
                              'assets/user_interface_icons/payment_process_icons/wall2.svg',
                              width: 20,
                              height: 20,
                            ),
                            SizedBox(width: 5),
                            Container(
                              height: 22,
                              width: 50,
                              child: FilledButton(
                                child: Text(
                                  "Room",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                  ),
                                ),
                                onPressed: () {},
                                style: FilledButton.styleFrom(
                                  backgroundColor: Color(0xFF00EFD1),
                                  padding: EdgeInsets.symmetric(vertical: 0),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text(
                          "Room 406",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Name",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "Nana Yaw",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Room type",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "4-in-a Room",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "No. of students",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "1",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Number of years",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "1 Year",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Date of move in",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "13-09-2023",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Date of move out",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "15-09-2025",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Payment method",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "Mobile Money",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Phone number",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "0590900888",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Divider(thickness: .5),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Email address",
                          style: TextStyle(fontSize: 12.sp.clamp(0, 12)),
                        ),
                        Text(
                          "oncampus@rainiertx.com",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomSheet: Container(
        height: 80,
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 10),
          child: SizedBox(
            child: ElevatedButton(
              onPressed: () async {
                // Get.to(
                //   () => Enquire(hostel: widget.hostel),
                //   transition: Transition.fadeIn,
                //   duration: const Duration(milliseconds: 800),
                //   curve: Curves.easeIn,
                // );
              },
              style: ElevatedButton.styleFrom(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  side: BorderSide.none,
                  borderRadius: BorderRadius.circular(15.r),
                ),
                backgroundColor: const Color(0xFF00EFD1),
              ),
              child: Center(
                child: Text(
                  "Proceed",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 19.sp.clamp(0, 19),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
